<?php
/**
 * Enqueues styles for front-end.
 */
function iwthemesfw_theme_styles() {

    wp_enqueue_style( 'iwthemesfw-style', get_stylesheet_uri() );
    wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/assets/icons/font-awesome/css/font-awesome.min.css' );

    // Add Google font, used in the main stylesheet.
    if (!class_exists('kirki')){
        if(!is_page_template('template-whmcs.php')): wp_enqueue_style( 'iwthemesfw_google_font', iwthemesfw_google_font_url(), array(), null ); endif;
    }

    if(is_page_template( 'template-rtl.php' )){
        wp_enqueue_style ('iwthemesfw-rtl', get_template_directory_uri().'/assets/css/rtl.css');
    }elseif( get_theme_mod( 'rtl_support') == 'enable'){
        wp_enqueue_style ('iwthemesfw-rtl', get_template_directory_uri().'/assets/css/rtl.css');
    }else{
        wp_enqueue_style ('iwthemesfw-main', get_template_directory_uri().'/assets/css/main.css');
    }

	// Get theme customizer variables
	$iwthemesfw_skin = get_theme_mod( 'skin_theme', '#f9b644' );
    $bg_body = get_theme_mod( 'bg_body', '#fff' );

	// Add custom styles
	$custom_css = "
        body{
            background: ".$bg_body.";
        }
        button, input[type='button'], input[type='reset'], input[type='submit'],
        .rev-btn,
        .bg_skin .eae-pt-action-button,
        .bg_skin input[type='submit'],
        .bg_skin .elementor-button,
        .bg_skin_section,
        .jRibbon,
        .line,
        .downarrow{
            background: $iwthemesfw_skin !important;
            background-color: $iwthemesfw_skin !important;
        }


        .page-template-template-whmcs .top-bar a:hover,
        .page-template-template-whmcs .site-header a:hover,
        .color_skin i,
        .color_skin h1,
        .color_skin h2,
        .color_skin h3,
        .color_skin h4,
        .color_skin h5,
        .color_skin h6,
        .color_skin .elementor-accordion-title.active,
        .color_skin .elementor-heading-title,
        .color_skin .elementor-testimonial-job,
        .color_skin .eae-at-animation-text-wrapper,
        .breadcrumbs .breadcrumbs-home i,
        .main-navigation #top-menu ul li:hover > a,
        .multicolumn_dropdown .mega_dropdown .menu-item > .item_link > i,
        .multicolumn_dropdown .mega_dropdown > li .mega_dropdown > li:hover a,
        .mega_dropdown .menu-item > .item_link > i,
        .site-navigation a:hover,
        .mega_main_menu_ul a:hover,
        .entry-content .more-btn,
        .custom-pagination .current,
        .post-list .content-entry .entry-meta .cat-links a:first-child:before,
        .single .content-entry .entry-meta .cat-links a:first-child:before,
        .post-list .content-entry .entry-meta .tags-links a:first-child:before,
        .single .content-entry .entry-meta .tags-links a:first-child:before,
        .post-list .content-entry .entry-content .more-btn,
        .single .content-entry .entry-summary .more-btn,
        .site-header .site-branding p,
        .site-footer .elementor a:hover,
        footer .elementor-icon-list-text:hover,
        .site-footer .site-info a:hover{
            color: $iwthemesfw_skin !important;
        }
    ";
	$custom_css = trim(preg_replace('/\s\s+/', ' ', $custom_css));
	if (!is_child_theme()) {

        if(is_page_template( 'template-rtl.php' )){
            wp_add_inline_style('iwthemesfw-rtl',$custom_css);
        }elseif( (get_theme_mod( 'rtl_support') == 'disable') or (get_theme_mod( 'rtl_support') == '') ){
            wp_add_inline_style('iwthemesfw-main',$custom_css);
        }else{
           wp_add_inline_style('iwthemesfw-rtl',$custom_css);
        }

	} else {
		wp_add_inline_style('iwthemesfw-main', $custom_css);
	}
}
add_action( 'wp_enqueue_scripts', 'iwthemesfw_theme_styles' );
