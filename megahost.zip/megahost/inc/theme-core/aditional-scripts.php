<?php
if(get_theme_mod( 'custom_scripts') != ''):
    function iwthemesfw_custom_scripts() {
       wp_add_inline_script( 'iwthemesfw-scripts', ''.esc_js(get_theme_mod( 'custom_scripts')).'' );
    }
    add_action( 'wp_enqueue_scripts', 'iwthemesfw_custom_scripts' );
endif;


if(get_theme_mod( 'google_maps') != ''):
    add_action( 'wp_enqueue_scripts', 'iwthemesfw_theme_maps' );
    function iwthemesfw_theme_maps() {
        wp_enqueue_script( 'iwthemesfw-maps', 'https://maps.googleapis.com/maps/api/js?key='.esc_attr(get_theme_mod( 'google_maps')).'');
    }
endif;
