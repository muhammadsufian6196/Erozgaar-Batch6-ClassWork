<?php get_template_part( 'components/header/top', 'support' ); ?>

<?php get_template_part( 'components/header/top-bar', 'elements' ); ?>

<header id="masthead" class="site-header" role="banner">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-12">
                <?php iwthemesfw_the_custom_logo(); ?>
                <?php get_template_part( 'components/header/site', 'branding' ); ?>
            </div>

            <div class="col-md-9 col-sm-12">
                <?php get_template_part( 'components/navigation/navigation', 'top' ); ?>
            </div>
        </div>
    </div>
</header>

<?php get_template_part( 'components/section-titles/title', 'default'); ?>
