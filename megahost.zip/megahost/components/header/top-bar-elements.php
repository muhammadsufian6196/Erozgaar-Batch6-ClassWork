<?php
$iwthemesfw_header_aling = get_theme_mod( 'aling_elements', 'left' );
$iwthemesfw_header_elements = get_theme_mod( 'heder_elements');
$iwthemesfw_header_show = '';

if( function_exists('get_field') ){
    if(get_field('style_header') != 'option_customizer'){
        if(!get_field('hidden_top_bar_elements')){
            $iwthemesfw_header_show = 'show';
        }
    }else{
        $iwthemesfw_header_show = get_theme_mod( 'show_elements', 'show' );
    }
}else{
    $iwthemesfw_header_show = get_theme_mod( 'show_elements', 'show' );
}
?>

<?php if( $iwthemesfw_header_show == 'show' ) : ?>
    <?php if($iwthemesfw_header_elements): ?>
    <div class="top-bar <?php echo esc_attr($iwthemesfw_header_aling); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul>
                    <?php foreach( $iwthemesfw_header_elements as $iwthemesfw_header_element ) : ?>
                        <li>
                            <i class="<?php echo esc_attr($iwthemesfw_header_element['icon_class']); ?>"></i>
                            <a href="<?php echo esc_url($iwthemesfw_header_element['link_url']); ?>">
                                <?php echo esc_html($iwthemesfw_header_element['title_text']); ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php endif; ?>
