<?php

    $style_title = '';
    $thumbnail_active = '';

    if( function_exists('get_field') ){
        $style_header = get_field('style_header');
        $style_header_customizer = get_theme_mod( 'styles_header' );

        if(($style_header != 'option_customizer')){
           if(($style_header == 'option_2')){
                $style_title = 'section-title-2 ';
            }
        }elseif(($style_header_customizer == 'header_2')){
            $style_title = 'section-title-2 ';
        }

        if ( has_post_thumbnail() ) {
            if(is_single()){
                if(get_field('hidden_background_image')){
                    $thumbnail_url = 'background: #232323;';
                    $thumbnail_active = ' ';
                }else{
                    $thumbnail_url = 'background: url('.get_the_post_thumbnail_url().');';
                    $thumbnail_active = 'thumbnail-bg ';
                }
            }else{
                $thumbnail_url = 'background: url('.get_the_post_thumbnail_url().');';
                $thumbnail_active = 'thumbnail-bg ';
            }
        }else{
            $thumbnail_url = 'background: #232323;';
        }

        if(get_field('text_alignment') != 'default'){
            $text_alignment = esc_html(get_field('text_alignment'));
        }else{
            $text_alignment = esc_html(get_theme_mod( 'aling_titles', 'left' ));
        }
    }else{
        $text_alignment = 'show';
    }
?>

<?php if($text_alignment != 'hidden'): ?>
<header class="section-title <?php echo esc_attr($thumbnail_active); echo esc_attr($style_title);  echo esc_attr($text_alignment); ?>" style="<?php echo esc_attr($thumbnail_url); ?>" >
    <div class="container">

        <?php
            if( function_exists('get_field') ){
                if(get_field('text_alignment') != 'default'){
                    if(get_field('breadcrumbs_show')){
                        if(get_field('breadcrumbs_show') == 'show_breadcrumbs'):
                            get_template_part( 'components/navigation/breadcrumbs');
                        endif;
                    }else{
                        get_template_part( 'components/navigation/breadcrumbs');
                    }
                }elseif(get_theme_mod( 'show_breadcrumbs' ) != 'hidden'){
                    get_template_part( 'components/navigation/breadcrumbs');
                }
            }else{
                get_template_part( 'components/navigation/breadcrumbs');
            }
        ?>

       <?php
            if(is_archive()){
                esc_html(the_archive_title( '<h1 class="entry-title">', '</h1>' ));
            }elseif(is_search()){
                echo '<h1 class="entry-title">'.esc_html__( 'Search Results for: ', 'megahost' ) . get_search_query() .'</h1>';
            }elseif(is_404()){
                 echo '<h1 class="entry-title">'.esc_html__( '404 Page ', 'megahost' ).'</h1>';
            }elseif(is_home()){
                echo '<h1 class="entry-title">'.esc_html( 'News' , 'megahost' ).'</h1>';
            }
            else{
                esc_html(the_title( '<h1 class="entry-title">', '</h1>' ));
            }
        ?>

        <?php if(!is_home()){ ?>
            <?php if(function_exists('the_field')): ?>
                <?php if(get_field('subtitle_info')): ?>
                    <p><?php esc_html(the_field('subtitle_info')); ?></p>
                <?php endif; ?>
            <?php endif; ?>
        <?php } ?>

        <?php if(is_archive() and !is_author()){ ?>
            <?php esc_html(the_archive_description( '<p class="taxonomy-description">', '</p>' )); ?>
        <?php } ?>

    </div>
</header>
<?php endif; ?>
