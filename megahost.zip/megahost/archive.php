<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package iwthemesfw
 */

get_header(); ?>

	<div id="primary" class="container">
        <div class="row">
            <main id="main" class="col-md-9" role="main">
                <?php
                if ( have_posts() ) : ?>
                    <?php
                    /* Start the Loop */
                    while ( have_posts() ) : the_post();

                        /*
                         * Include the Post-Format-specific template for the content.
                         * If you want to override this in a child theme, then include a file
                         * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                         */
                        get_template_part( 'components/post/content', get_post_format() );

                    endwhile;

                    iwthemesfw_pagination();

                else :

                    get_template_part( 'components/post/content', 'none' );

                endif; ?>

                </main>
	           <div class="col-md-3">
                <?php get_sidebar(); ?>
            </div>

        </div>
	</div>
<?php
get_footer();
