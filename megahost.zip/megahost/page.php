<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package iwthemesfw
 */

get_header(); ?>

    <?php
        $iwthemesfw_page_sidebar = '';
        $iwthemesfw_page_sidebar_full = 'col-md-12';
        if( function_exists('get_field') ){
            $iwthemesfw_page_sidebar = esc_html(get_field( 'sidebar_option'));
            if($iwthemesfw_page_sidebar){
                if($iwthemesfw_page_sidebar == 'hidden'){
                    $iwthemesfw_page_sidebar_full = 'col-md-12';
                }else{
                    $iwthemesfw_page_sidebar_full = 'col-md-9';
                }
            }else{
                $iwthemesfw_page_sidebar_full = 'col-md-12';
            }
        }else{
            $iwthemesfw_page_sidebar_full = 'col-md-12';
        }
    ?>

	<div id="primary" class="container">
        <div class="row">

            <?php if($iwthemesfw_page_sidebar == 'left'): ?>
                 <div class="col-md-3">
                    <?php get_sidebar(); ?>
                </div>
            <?php endif; ?>

            <main id="main" class="<?php echo esc_attr($iwthemesfw_page_sidebar_full); ?>" role="main">

                <?php
                while ( have_posts() ) : the_post();

                    get_template_part( 'components/page/content', 'page' );

                    // If comments are open or we have at least one comment, load up the comment template.
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;

                endwhile; // End of the loop.
                ?>

            </main>

            <?php if($iwthemesfw_page_sidebar == 'right'): ?>
                 <div class="col-md-3">
                    <?php get_sidebar(); ?>
                </div>
            <?php endif; ?>

        </div>
    </div>
<?php
get_footer();
